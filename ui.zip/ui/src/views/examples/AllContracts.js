import React from 'react'
import ContractListView from './ContractListView'

export default function AllContracts() {
    return (

        <div>
            <ContractListView status="all"title="All Contract List"/>
        </div>
    )
}
