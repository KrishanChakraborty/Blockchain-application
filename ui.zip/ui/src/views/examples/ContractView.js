import React, { useState, useEffect } from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, FormFeedback, Card, FormGroup, Label, Input, Col, CustomInput } from 'reactstrap';
import ProgressBar from './ProgressBar';
import { useToasts } from 'react-toast-notifications';
import { getTimeStamp } from '../../helper/utils';
import { useDispatch, useSelector } from 'react-redux';
import * as AgreementAction from '../../actions/agreement';

const ContractView = (props) => {
  const { addToast } = useToasts();
  const dispatch = useDispatch();
  const { contractDetails, modal, toggle } = props;


  const decodedData = useSelector((state) => state?.User?.login?.decodedData);

  const [editedContractDetails, setEditedContractDetails] = useState({
    title: '',
//    contract: '', //@ben
    typeOfContract: '',
    contractDetails: '',
    startDate: '',
    endDate: '',
    comment: '',
    document: null,
  });
  const [isValidating, setIsValidating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (contractDetails) {
      console.log("Contract details here==>",contractDetails);
      setEditedContractDetails(contractDetails);
    }
  }, [contractDetails]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedContractDetails(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const validateAndAddContract = () => {
    setIsValidating(true);

    // Validate contract details
    const isInvalid = Object.keys(editedContractDetails).some(key => editedContractDetails[key] === '' && key !== 'document');
    if (isInvalid || !editedContractDetails.document) {
      addToast(`Please fill in all required fields`, {
        appearance: 'error',
        autoDismiss: true,
      });
      return;
    }

    setIsLoading(true);

    // Construct FormData
    const data = new FormData();
    
    data.append('typeOfContract', editedContractDetails.typeOfContract);
    data.append('title', editedContractDetails.title);
    data.append('contract', editedContractDetails.contractDetails);
    data.append('firstParty', decodedData?.orgId === 1 ? 'Org1' : 'Org2');
    data.append('secondParty', decodedData?.orgId === 1 ? 'Org2' : 'Org1');
    data.append('startDate', getTimeStamp(String(editedContractDetails.startDate)));
    data.append('endDate', getTimeStamp(String(editedContractDetails.endDate)));
    data.append('comment', editedContractDetails.comment);
    data.append('agreement', editedContractDetails.document);


    // Dispatch action to update contract details
    dispatch(AgreementAction.createAgreement(data))
      .then(() => {
        addToast('Contract details updated successfully', {
          appearance: 'success',
          autoDismiss: true,
        });
        toggle(); // Close modal after editing
      })
      .catch((error) => {
        console.error(error);
        alert('Error updating contract details');
      })
      .finally(() => {
        setIsLoading(false);
        setIsValidating(false);
      });
  };

  const getFile = (e) => {
    const file = e.target.files[0];
    setEditedContractDetails(prevState => ({
      ...prevState,
      document: file
    }));
  };

  return (
    <div>
      <Modal isOpen={modal} toggle={toggle} size="lg">
        <ModalHeader toggle={toggle}>Edit Contract Details</ModalHeader>
        <ModalBody>
          <FormGroup row>
            <Label sm={2}>Title</Label>
            <Col sm={10}>
              <Input type="text" name="title" value={editedContractDetails.title} onChange={handleChange} invalid={isValidating && editedContractDetails.title === ''} />
              <FormFeedback>*Required</FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row>
            <Label sm={2}>IRS generation Type</Label>
            <Col sm={10}>
              <Input type="text" name="typeOfContract" value={editedContractDetails.typeOfContract} onChange={handleChange} invalid={isValidating && editedContractDetails.typeOfContract === ''} />
              <FormFeedback>*Required</FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row>
            <Label sm={2}>ICD weapon</Label>
            <Col sm={10}>
              <Input type="textarea" name="contractDetails" value={editedContractDetails.contractDetails} onChange={handleChange} invalid={isValidating && editedContractDetails.contractDetails === ''} />
              {/* /@ben */}
              {/*<Input type="textarea" name="contractDetails" value={editedContractDetails.contract} onChange={handleChange} invalid={isValidating && editedContractDetails.contract === ''} />*/}

              <FormFeedback>*Required</FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row>
            <Label sm={2}>Start Date</Label>




            <Col sm={10}>
              <Input type="date" name="startDate" value={editedContractDetails.startDate} onChange={handleChange} invalid={isValidating && editedContractDetails.startDate === ''} />
              <FormFeedback>*Required</FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row>
            <Label sm={2}>End Date</Label>
            <Col sm={10}>
              <Input type="date" name="endDate" value={editedContractDetails.endDate} onChange={handleChange} invalid={isValidating && editedContractDetails.endDate === ''} />
              <FormFeedback>*Required</FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row>
            <Label sm={2}>Comment</Label>
            <Col sm={10}>
              <Input type="text" name="comment" value={editedContractDetails.comment} onChange={handleChange} invalid={isValidating && editedContractDetails.comment === ''} />
              <FormFeedback>*Required</FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row>
            <Label sm={2}>Document</Label>
            <Col sm={10}>
              <CustomInput type="file" id="exampleCustomFile" name="customFile" onChange={getFile} />
              {isValidating && !editedContractDetails.document && <FormFeedback className="d-block">*Required</FormFeedback>}
            </Col>
          </FormGroup>
        </ModalBody>
        <ModalFooter>
          <Button color="primary" onClick={validateAndAddContract} disabled={isLoading}>Save Changes</Button>{' '}
          <Button color="secondary" onClick={toggle} disabled={isLoading}>Cancel</Button>
        </ModalFooter>
        {isLoading && <ProgressBar />}
      </Modal>
    </div>
  );
};

export default ContractView;
