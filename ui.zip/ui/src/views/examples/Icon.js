import React from 'react'
import icon from '../../assets/img/brand/favicon.png'

export default function Icon() {
    return (
        <div>
            <img source={icon} alt="pavan" height={200} width={200}></img>
            
        </div>
    )
}
