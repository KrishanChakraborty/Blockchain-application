#!/bin/bash

# Check if the channel name is provided
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <channel_name>"
    exit 1
fi

# Assign the first argument to CHANNEL_NAME
CHANNEL_NAME=$1

# channel name defaults to "mychannel"
#CHANNEL_NAME="mychannel"

echo $CHANNEL_NAME

# Generate Channel Genesis block
configtxgen -profile ThreeOrgsApplicationGenesis -configPath . -channelID $CHANNEL_NAME  -outputBlock ../../channel-artifacts/$CHANNEL_NAME.block

