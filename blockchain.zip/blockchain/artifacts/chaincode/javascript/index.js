'use strict';

const agreement = require('./lib/agreement');

module.exports.AssetTransfer = agreement;
module.exports.contracts = [agreement];
