#!/bin/bash

# Check if the channel name is provided
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <channel_name>"
    exit 1
fi

# Assign the first argument to CHANNEL_NAME
CHANNEL_NAME=$1


# Note: We are considering , we already created all participants certioficates

# 2) Create Artifacts
cd ../artifacts/channel/ && ./create-artifacts.sh ${CHANNEL_NAME}

cd ..

cd ../scripts
# 4) Craete Channel
./createChannel.sh ${CHANNEL_NAME}

# 5) Deploy chaincode
./deployChaincode.sh ${CHANNEL_NAME}